//
//  ViewController.swift
//  slider
//
//  Created by MacBook on 01/06/18.
//  Copyright © 2018 MacBook. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    
    @IBOutlet weak var Logo: UIImageView!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var nivel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    
        
    }
    
    
    @IBAction func gelValueSlider(_ sender: Any) {
        //print(slider.value)
        let valor = Int(slider.value * 100)
        
        let cadena = "\(valor)%"
        //print(cadena)
        Label.text = cadena
        switch valor {
        case 0...33:
            nivel.text = "Amanecer"
            Logo.image = UIImage(named: "Amanecer")
            
        case 34...66:
            nivel.text = "Medio día"
            Logo.image = UIImage(named: "Medio_dia")
        default:
            nivel.text = "Noche"
            Logo.image = UIImage(named: "Anochecer")
        }
        
    }
    
    @IBOutlet weak var Label: UILabel!
   
}

