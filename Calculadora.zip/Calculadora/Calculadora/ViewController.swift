//
//  ViewController.swift
//  Calculadora
//
//  Created by Javier Serrano on 10/06/18.
//  Copyright © 2018 Javier Serrano. All rights reserved.
//




//Hacer la simulacion en un iPhone SE

import UIKit

class ViewController: UIViewController {
    
    var numeroEnPantalla: Double = 0;
    var numeroAnterior: Double = 0;
    var performingMath = false
    var operacion = 0;
    
    @IBOutlet weak var resultado: UILabel!
    
    @IBAction func numeros(_ sender: UIButton)
    {
        if performingMath == true
        {
            resultado.text = String(sender.tag-1)
            numeroEnPantalla = Double(resultado.text!)!
            performingMath = false
        }
        else
        {
            resultado.text = resultado.text! + String(sender.tag-1)
            numeroEnPantalla = Double(resultado.text!)!
        }
    }
    
    @IBAction func Botones(_ sender: UIButton)
    {
        if resultado.text != "" && sender.tag != 11 && sender.tag != 16{
            
            numeroAnterior = Double(resultado.text!)! ////////////
            
            if sender.tag == 12 //division
            {
                resultado.text = "/";
            }
            else if sender.tag == 13 //multiplicacion
            {
                resultado.text = "x";
            }
            else if sender.tag == 14 //resta
            {
                resultado.text = "-";
            }
            else if sender.tag == 15 // suma
            {
                resultado.text = "+";
            }
            operacion = sender.tag
            performingMath = true;
        }
         else if sender.tag == 16
        {
            if operacion == 12
            {
               resultado.text = String(numeroAnterior / numeroEnPantalla)
            }
            else if operacion == 13
            {
                resultado.text = String(numeroAnterior * numeroEnPantalla)
            }
            else if operacion == 14
            {
              resultado.text = String(numeroAnterior - numeroEnPantalla)
            }
           else if operacion == 15
            {
                resultado.text = String(numeroAnterior + numeroEnPantalla)
            }
        }
        else if resultado.tag == 11
        {
            resultado.text = ""
            numeroAnterior = 0;
            numeroEnPantalla = 0;
            operacion = 0;
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

