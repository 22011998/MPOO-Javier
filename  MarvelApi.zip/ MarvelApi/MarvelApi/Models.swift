//
//  Models.swift
//  MarvelApi
//
//  Created by macbook on 16/05/18.
//  Copyright © 2018 macbook. All rights reserved.
//

import UIKit

struct SuperHero {
    var name : String
    var description : String
    var imageLink : String
    var image : UIImage?
}
